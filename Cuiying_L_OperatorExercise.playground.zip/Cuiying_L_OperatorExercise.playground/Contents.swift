//top section (integers must be entered as a decimal)
var A = 1.243
var B = 15.0

//middle section
let sum = Float((A + B))
let difference = Float((A - B))
let product = Float((A * B))
let quotient = Float((A / B))

//bottom section
print("The sum of \(A) and \(B) is \(sum). \nThe difference of \(A) and \(B) is \(difference). \nThe product of \(A) and \(B) is \(product). \nThe quotient of \(A) and \(B) is \(quotient).")
